// INCOLLA QUI IL CODICE COMPLETO DAL CANVAS CHATGPT
// Nome componente: MacroFoodCalendarApp oppure export default function ...
// Importante: se il canvas contiene `export default function MacroFoodCalendarApp()`, lascialo così.

export default function App() {
  return (
    <div style={{ padding: 24, fontFamily: 'system-ui' }}>
      <h1>🍝 Cosa mangio</h1>
      <p>Apri src/App.jsx e incolla qui il codice completo dell'app dal canvas ChatGPT.</p>
    </div>
  );
}
